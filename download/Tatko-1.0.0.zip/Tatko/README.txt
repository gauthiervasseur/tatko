TATKO 1.0.0 - 8-bit business intelligence for CSV files
====================================================

START
  Double-click index.html. It opens in your web browser (Chrome, Edge,
  Firefox or Safari). Nothing to install, no internet needed, and your data
  never leaves your computer.

PLAY
  1. LOAD CSV (or drop a .csv file onto the window). Try samples/pixel-mart-sales.csv.
  2. Drag fields from the left onto COLUMNS, ROWS, VALUES and COLOR.
  3. Pick a chart type, or leave AUTO.
  4. Drop fields on FILTERS to filter. Use the swap button to pivot rows and columns.
  5. Click a pill to change SUM/AVG/... or YEAR/MONTH/...

THEMES
  THEME CSS loads a .css file with your colors and fonts. Examples are in
  themes/. Supported variables are listed in the THEME tab and in
  themes/arcade.css.

SAVE / LOAD
  SAVE writes a .tatko.json file with your sheets, filters and theme (not the
  data). LOAD it, then load the matching CSV.

CREDITS
  Charts: plotly.js (MIT license) - vendor/
  Fonts: Press Start 2P and VT323 (SIL Open Font License) - fonts/
